<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('element_modules', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('module_id');
 
            $table->foreign('module_id')->references('id')->on('modules');
            $table->unsignedBigInteger('prof_id');
 
            $table->foreign('prof_id')->references('id')->on('proffesseurs');
            $table->string('nom');
            $table->string('code');
            $table->float('poids');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('element_modules');
    }
};
