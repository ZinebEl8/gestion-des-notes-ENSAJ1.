<!DOCTYPE html>
<html>
    <head>
        <title>Connexion</title>
    </head>
    <body>
        <h1>Connexion</h1>
        <form action="/login" method="Get">
            <?php echo csrf_field(); ?>
            <label for="username">Nom d'utilisateur:</label>
            <input type="text" id="username" name="username">
            <br>
            <label for="password">Mot de passe:</label>
            <input type="password" id="password" name="password">
            <br>
            <button type="submit">Se connecter</button>
        </form>
    </body>
</html>
<?php /**PATH /home/ikram/gestion-des-notes-ENSAJ/resources/views/login.blade.php ENDPATH**/ ?>