<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.108.0">
    <title>Features · Bootstrap v5.3</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Patua+One&display=swap" rel="stylesheet">
    <style>
      {
  
       font-family: 'Patua One', cursive;
      }
      .feature-icon {
  width: 4rem;
  height: 4rem;
  border-radius: .75rem;
}

.icon-link > .bi {
  margin-top: .125rem;
  margin-left: .125rem;
  fill: currentcolor;
  transition: transform .25s ease-in-out;
}
.icon-link:hover > .bi {
  transform: translate(.25rem);
}

.icon-square {
  width: 3rem;
  height: 3rem;
  border-radius: .75rem;
}

.text-shadow-1 { text-shadow: 0 .125rem .25rem rgba(0, 0, 0, .25); }
.text-shadow-2 { text-shadow: 0 .25rem .5rem rgba(0, 0, 0, .25); }
.text-shadow-3 { text-shadow: 0 .5rem 1.5rem rgba(0, 0, 0, .25); }

.card-cover {
  background-repeat: no-repeat;
  background-position: center center;
  background-size: cover;
}

.feature-icon-small {
  width: 3rem;
  height: 3rem;
}

      

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }

      


    </style>

    
    <!-- Custom styles for this template -->
    <link href="features.css" rel="stylesheet">
  </head>
  <body>
<main>
  <h1 class="visually-hidden">Espace Admin</h1>
<div class="container px-4 py-5" id="hanging-icons">
    <h2 class="pb-2 border-bottom">Gestion des comptes </h2>
    <div class="row g-4 py-5 row-cols-1 row-cols-lg-3">
      <div class="col d-flex align-items-start">
        <div class="icon-square text-bg-light d-inline-flex align-items-center justify-content-center fs-4 flex-shrink-0 me-3">
          <svg class="bi" width="1em" height="1em"><use xlink:href="#toggles2"/></svg>
        </div>
        <div>
          <h3 class="fs-2">Compte Etudiant</h3>
          <a href="/students/create" class="btn btn-primary">
            Ajouter 
          </a><br>
          <a href="karoma2" class="btn btn-primary">
            modifier
          </a><br>
          <a href="/students" class="btn btn-primary">
            suprimer
          </a>
        </div>
      </div>
      <div class="col d-flex align-items-start">
        <div class="icon-square text-bg-light d-inline-flex align-items-center justify-content-center fs-4 flex-shrink-0 me-3">
          <svg class="bi" width="1em" height="1em"><use xlink:href="#cpu-fill"/></svg>
        </div>
        <div>
          <h3 class="fs-2">Compte Professeur</h3>
          <a href="karoma1" class="btn btn-primary">
            Ajouter 
          </a><br>
          <a href="karoma1" class="btn btn-primary">
            Supprimer
          </a><br>
          <a href="karoma1" class="btn btn-primary">
            Modifier
          </a>
        </div>
      </div>
        <div class="col d-flex align-items-start">
          <div class="icon-square text-bg-light d-inline-flex align-items-center justify-content-center fs-4 flex-shrink-0 me-3">
            <svg class="bi" width="1em" height="1em"><use xlink:href="#cpu-fill"/></svg>
          </div>
          <div>
            <h3 class="fs-2">Compte Administrateur</h3>
            <a href="karoma1" class="btn btn-primary">
              Ajouter 
            </a><br>
            <a href="karoma1" class="btn btn-primary">
              Supprimer
            </a><br>
            <a href="karoma1" class="btn btn-primary">
              Modifier
            </a>
          </div>
          
        </div>
  
        
      </div>

      <div class="container px-4 py-5" id="hanging-icons">
        <h2 class="pb-2 border-bottom">Gestion du formation  </h2>
        <div class="row g-4 py-5 row-cols-1 row-cols-lg-3">
          <div class="col d-flex align-items-start">
            <div class="icon-square text-bg-light d-inline-flex align-items-center justify-content-center fs-4 flex-shrink-0 me-3">
              <svg class="bi" width="1em" height="1em"><use xlink:href="#toggles2"/></svg>
            </div>
            <div>
              <h3 class="fs-2">Filiére</h3>
              <a href="karoma1" class="btn btn-primary">
                Ajouter 
              </a><br>
              <a href="karoma1" class="btn btn-primary">
                Supprimer
              </a><br>
              <a href="karoma1" class="btn btn-primary">
                Modifier
              </a>
            </div>
          </div>
          <div class="col d-flex align-items-start">
            <div class="icon-square text-bg-light d-inline-flex align-items-center justify-content-center fs-4 flex-shrink-0 me-3">
              <svg class="bi" width="1em" height="1em"><use xlink:href="#cpu-fill"/></svg>
            </div>
            <div>
              <h3 class="fs-2">Module</h3>
              <a href="karoma1" class="btn btn-primary">
                Ajouter 
              </a><br>
              <a href="karoma1" class="btn btn-primary">
                Supprimer
              </a><br>
              <a href="karoma1" class="btn btn-primary">
                Modifier
              </a>
            </div>
      
          </div>
    
    </main>


    <script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>

      
  </body>
</html><?php /**PATH /home/ikram/Downloads/gestion-des-notes-ENSAJ/resources/views/admin/page_admin.blade.php ENDPATH**/ ?>