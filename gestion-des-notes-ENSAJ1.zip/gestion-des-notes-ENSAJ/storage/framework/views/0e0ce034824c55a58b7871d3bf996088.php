<!DOCTYPE html>
<html>
  <head>
    <title>Login Page</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
    body {
  margin: 0;
  padding: 0;
  background: #f2f2f2;
}

.login {
  width: 400px;
  margin: 0 auto;
  background: #fff;
  padding: 20px;
  border-radius: 5px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
}

.login h1 {
  text-align: center;
  font-size: 36px;
  margin-bottom: 30px;
}

.login form {
  display: flex;
  flex-direction: column;
}

.login label {
  font-size: 18px;
  margin-bottom: 10px;
}

.login input[type="text"],
.login input[type="password"] {
  padding: 10px;
  margin-bottom: 20px;
  border: none;
  border-radius: 5px;
  box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
}

.login button[type="submit"] {
  padding: 10px;
  background: #007bff;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background 0.3s ease;
}

.login button[type="submit"]:hover {
  background: #0069d9;

}
.forgot-password {
  text-align: center;
  margin-top: 10px;
}
</style>
  </head>
  <body>
    <div class="login">
        <?php echo csrf_field(); ?>
      <h1>Login</h1>
      <form method="post" >
        <label for="email">Email:</label>
        <input type="text" id="email" name="email" placeholder="Enter email" required>

        <label for="password">mot de passe:</label>
        <input type="password" id="password" name="password" placeholder="Enter password" required>

        <button type="submit" ><a href=/karoma>Login</a></button>
        <label class="forgot-password"><a href="/page">mot de passe oublié?</a></label>
      </form>
    </div>
  </body>
</html>
<?php /**PATH /home/ikram/Downloads/gestion-des-notes-ENSAJ/resources/views/admin/login.blade.php ENDPATH**/ ?>