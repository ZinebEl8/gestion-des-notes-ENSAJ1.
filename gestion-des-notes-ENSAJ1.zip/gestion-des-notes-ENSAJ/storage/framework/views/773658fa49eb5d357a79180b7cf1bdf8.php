<form method="POST" action="<?php echo e(route('students.destroy', $student->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button type="submit" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cet étudiant ?')">Supprimer</button>
</form><?php /**PATH /home/ikram/Downloads/gestion-des-notes-ENSAJ/resources/views/students/delete.blade.php ENDPATH**/ ?>