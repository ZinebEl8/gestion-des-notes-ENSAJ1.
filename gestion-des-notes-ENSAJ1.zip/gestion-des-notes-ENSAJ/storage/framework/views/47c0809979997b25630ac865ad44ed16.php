<!-- resources/views/students/edit.blade.php -->
<!DOCTYPE html>
<html>
    <head>
        <title>Modifier Étudiant</title>
    </head>
    <body>
        <div class=login>
        <h1>Supprimer Étudiant</h1>
        <form method="post" action="<?php echo e(route('students.edit', $student->id)); ?>">
            <?php echo csrf_field(); ?>
            
            <div>
        <label for="first_name">Prénom :</label>
        <input type="text" name="first_name" id="first_name" value="<?php echo e(old('first_name')); ?>" required>
    </div>
    <div>
        <label for="last_name">Nom de famille :</label>
        <input type="text" name="last_name" id="last_name"  required>
    </div>
    <div>
        <label for="password">Mot de passe :</label>
        <input type="password" name="password" id="password" required>
    </div>
    <div>
        <label for="email">Adresse e-mail :</label>
        <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" required>
    </div>
    <div>
        <label for="CNE">Code-Nationale-d'étudiant:</label>
        <input type="text" name="CNE" id="CNE" value="<?php echo e(old('CNE')); ?>" required>
    </div>  
   
    
        </form>
        <form method="POST" action="<?php echo e(route('students.destroy', $student->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cet étudiant ?')">Supprimer</button>
        </form>
        </div>
    </body>
</html><?php /**PATH /home/ikram/Downloads/gestion-des-notes-ENSAJ/resources/views/students/edit.blade.php ENDPATH**/ ?>