<!-- resources/views/students/edit.blade.php -->
<!DOCTYPE html>
<html>
    <head>
        <title>Modifier Étudiant</title>
    </head>
    <body>
        <h1>Modifier Étudiant</h1>
        <form method="POST" action="<?php echo e(route('students.update', $student->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div>
                <label for="username">Nom d'utilisateur :</label>
                <input type="text" name="username" id="username" value="<?php echo e(old('username', $student->username)); ?>" required>
            </div>
            <div>
                <label for="password">Mot de passe :</label>
                <input type="password" name="password" id="password">
                <p>Laissez le champ vide si vous ne souhaitez pas changer le mot de passe actuel.</p>
            </div>
            <div>
                <label for="email">Adresse e-mail :</label>
                <input type="email" name="email" id="email" value="<?php echo e(old('email', $student->email)); ?>" required>
            </div>
            <div>
                <label for="first_name">Prénom :</label>
                <input type="text" name="first_name" id="first_name" value="<?php echo e(old('first_name', $student->first_name)); ?>" required>
            </div>
            <div>
                <label for="last_name">Nom de famille :</label>
                <input type="text" name="last_name" id="last_name" value="<?php echo e(old('last_name', $student->last_name)); ?>" required>
            </div>
            <div>
                <label for="phone_number">Numéro de téléphone :</label>
                <input type="text" name="phone_number" id="phone_number" value="<?php echo e(old('phone_number', $student->phone_number)); ?>">
            </div>
            <div>
                <label for="address">Adresse :</label>
                <input type="text" name="address" id="address" value="<?php echo e(old('address', $student->address)); ?>">
            </div>
            <div>
                <label for="role">Rôle :</label>
                <select name="role" id="role" required>
                    <option value="student" <?php if($student->role == 'student'): ?> selected <?php endif; ?>>Étudiant</option>
                    <option value="teacher" <?php if($student->role == 'teacher'): ?> selected <?php endif; ?>>Enseignant</option>
                </select>
            </div>
            <button type="submit">Modifier</button>
        </form>
    </body>
</html><?php /**PATH /home/ikram/Downloads/gestion-des-notes-ENSAJ/resources/views/students/update.blade.php ENDPATH**/ ?>