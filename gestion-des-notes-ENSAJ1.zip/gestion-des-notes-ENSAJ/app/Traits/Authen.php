<?php

namespace App\Traits;

use Illuminate\Support\Facades\Auth;

trait Authen
{
    public function login(Authen $user)
    {
        Auth::login($user);
    }
    

    public function logout()
    {
        // Log the user out using Laravel's built-in authentication
        Auth::logout();
    }

    public function forgetpassword()
    {
        // Handle password reset logic here
    }
}
