<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class proffesseur extends Model
{
    use HasFactory;
    protected $guarded = [];

   
    public function user()
    {
        return $this->belongsTo(User::class);
    }
    public function element_module()
    {
        return $this->hasMany(élément_de_module::class);
    }
}
