<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use Illuminate\Http\Request;
use App\Models\Student;
use Illuminate\Support\Facades\Auth;



class AdminController extends Controller
{
   
    /**
     * Display a listing of the resource.
     */
    public function login(Request $request)
    {
        // Récupérez les informations de la requête POST
        $email = $request->input('email');
        $password = $request->input('password');

        // Effectuez une recherche dans la table des administrateurs
        $admin = Admin::where('email', $email)->first();

        // Vérifiez si l'administrateur existe et si le mot de passe est correct
        if ($admin && password_verify($password, $admin->password)) {
            // Les informations sont correctes, affichez la page principale
            return view('admin.page_admin');
        } else {
            // Les informations sont incorrectes, redirigez l'utilisateur vers la page de connexion avec un message d'erreur
            return redirect('/admin/login')->with('error', 'Identifiants incorrects');
        }
    }

    public function index()
    {
        //
    }
}