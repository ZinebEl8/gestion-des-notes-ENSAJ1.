<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Student;


class StudentController extends Controller
{
    
public function index()
{
    $students = Student::all();
    return view('students.index', ['students' => $students]);
}


public function show($id)
{
    // Récupérer l'étudiant correspondant à l'identifiant $id
    $student = Student::findOrFail($id);

    // Afficher la vue de l'étudiant avec les données récupérées
    return view('students.show', ['student' => $student]);
}


/**
* Show the form for creating a new resource.
*/
public function create()
{
    return view('students.create');
}

/**
* Store a newly created resource in storage.
*/
public function store(Request $request)
{
    // Valide les données du formulaire
    $request->validate([
        
        'first_name' => 'required',
        'last_name' => 'required',
        'password' => 'required',
        'email' => 'required|email|unique:students',
        'CNE' => 'required',
        
    ]);

    // Stocke les données dans la base de données
    $student = new Student();
   
    
    $student->first_name = $request->input('first_name');
    $student->last_name = $request->input('last_name');
    $student->password = bcrypt($request->input('password'));
    $student->email = $request->input('email');
    $student->CNE= $request->input('CNE');
    $student->save();

    // Redirige l'utilisateur vers la page d'accueil des étudiants avec un message de confirmation
    return redirect()->route('students.index')->with('success', 'Nouvel étudiant créé avec succès !');
}

/**
* Display the specified resource.
*/

/**
* Show the form for editing the specified resource.
*/
public function edit($id)
{
    $student = Student::find($id);
    return view('students.edit', compact('student'));
}

/**
* Update the specified resource in storage.
*/
public function update(Request $request, $id)
{
    $student = Student::find($id);
    $student->username = $request->input('username');
    $student->email = $request->input('email');
    $student->first_name = $request->input('first_name');
    $student->last_name = $request->input('last_name');
    $student->phone_number = $request->input('phone_number');
    $student->address = $request->input('address');
    $student->role = $request->input('role');

    // Vérifie si le mot de passe est différent de l'ancien mot de passe avant de le hasher
    if ($request->input('password') !== $student->password) {
        $student->password = bcrypt($request->input('password'));
    }

    $student->save();
    return redirect()->route('students.index')->with('success', 'Étudiant modifié avec succès.');
}

/**
* Remove the specified resource from storage.
*/
public function destroy($id)
{
    $student = Student::findOrFail($id);
    $student->delete();

    return redirect()->route('students.index')->with('success', 'L\'étudiant a été supprimé avec succès.');
}

}





