<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\note;

class NoteController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function notesModule(Request $request, $module_id)
    {
        // Récupérer les notes pour un module donné
        $notes = Note::where('module_id', $module_id)->get();

        // Vérifier si toutes les notes pour les sous-modules ont été saisies
        $notes_sous_modules = $notes->where('type', 'sous_module');
        $notes_saisies_sous_modules = $notes_sous_modules->whereNotNull('note');
        if ($notes_sous_modules->count() == $notes_saisies_sous_modules->count()) {
            // Toutes les notes pour les sous-modules ont été saisies, l'étudiant peut voir la note de module
            $note_module = $notes->where('type', 'module')->first();
        } else {
            // Les notes pour les sous-modules ne sont pas encore toutes saisies, l'étudiant ne peut pas voir la note de module
            $note_module = null;
        }

        return view('notes_module', [
            'notes' => $notes,
            'note_module' => $note_module
        ]);
    }
    public function notesSemestre(Request $request, $annee, $num_semestre)
    {
        // Récupérer toutes les notes pour un semestre donné
        $notes_semestre = Note::type('module')->semestre($annee, $num_semestre)->get();

        // Vérifier si toutes les notes pour les modules ont été saisies
        $modules = $notes_semestre->pluck('module')->unique();
        $notes_saisies_modules = $modules->map(function ($module) use ($notes_semestre) {
            $notes_module = $notes_semestre->where('module_id', $module->id);
            $notes_sous_modules = $notes_module->where('type', 'sous_module');
            $notes_saisies_sous_modules = $notes_sous_modules->whereNotNull('note');
            if ($notes_sous_modules->count() == $notes_saisies_sous_modules->count()) {
                // Toutes les notes pour les sous-modules ont été saisies
                return $notes_module->where('type', 'module')->first();
            } else {
                // Les notes pour les sous-modules ne sont pas encore toutes saisies
                return null;
            }
        });

        // Vérifier si toutes les notes pour les modules ont été saisies
        $notes_saisies_modules = $notes_saisies_modules->filter();
        if ($modules->count() == $notes_saisies_modules->count()) {
            // Toutes les notes pour les modules ont été saisies, calculer la note du semestre
            $note_semestre = $notes_saisies_modules->sum('note') / $notes_saisies_modules->count();
        } else {
            // Les notes pour les modules ne sont pas encore toutes saisies, l'étudiant ne peut pas voir la note de semestre
            $note_semestre = null;
        }

        return view('notes_semestre', [
            'notes_semestre' => $notes_semestre,
            'note_semestre' => $note_semestre
        ]);
    }
    
    public function notesAnnee(Request $request, $annee)
    {
        // Récupérer toutes les notes pour une année donnée
        $notes_annee = Note::type('semestre')->annee($annee)->get();

        // Vérifier si toutes les notes pour les deux semestres ont été saisies
        $notes_semestre_1 = $notes_annee->where('num_semestre', 1);
        $notes_semestre_2 = $notes_annee->where('num_semestre', 2);
        if ($notes_semestre_1->count() == 1 && $notes_semestre_2->count() == 1) {
            $note_semestre_1 = $notes_semestre_1->first();
            $note_semestre_2 = $notes_semestre_2->first();
            if ($note_semestre_1->note != null && $note_semestre_2->note != null) {
                // Toutes les notes pour les deux semestres ont été saisies, calculer la note de l'année
                $note_annee = ($note_semestre_1->note + $note_semestre_2->note) / 2;
            } else {
                // Les notes pour les deux semestres ne sont pas encore toutes saisies, l'étudiant ne peut pas voir la note de l'année
                $note_annee = null;
            }
        } else {
            // Les notes pour les deux semestres ne sont pas encore toutes saisies, l'étudiant ne peut pas voir la note de l'année
            $note_annee = null;
        }

        return view('notes_annee', [
            'notes_annee' => $notes_annee,
            'note_annee' => $note_annee
        ]);
    }


    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
