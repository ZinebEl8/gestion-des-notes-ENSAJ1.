<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\test;
use App\Http\Controllers\StudentController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|


Route::get('/', function () {
    return view('welcome');
});*/
Route::get('/', function () {
    return view('welcome');
});

Route::get('/page', function () {
    return view('admin.page');

});
Route::get('/karoma', function () {
    return view('admin.page_admin');
});
Route::get('/admin/login',function () {
    return view('admin.login');
});
Route::post('/login', [AdminController::class,'login'])->name('admin.login');


/*Route::post('/login', function (Request $request) {
    $credentials = $request->only('username', 'password');
    if (Auth::attempt($credentials)) {
        // L'utilisateur est connecté avec succès
        return redirect('/dashboard');
    } else {
        // Les informations de connexion sont incorrectes
        return back()->withErrors([
            'message' => 'Les informations de connexion sont incorrectes.',
        ]);
    }
});




Route::group(['middleware' => ['auth', 'admin']], function() {
    Route::post('/admin/create-student-account', [AdminController::class, 'createStudentAccount'])->name('admin.create-student-account');
});
/*Route::middleware('admin')->group(function () {
    // Routes du contrôleur AdminController
});
Route::get('/', [test::class,'index']
);*/


Route::get('/karoma1', function () {
    return view('students.create');});
Route::get('/karoma2', function () {
        return view('students.edit');
});
Route::get('/karoma3', function () {
    return view('students.delete');
});
Route::get('/students/create', [StudentController::class, 'create'])->name('students.create');

Route::post('/students', [StudentController::class,'store'])->name('students.store');

Route::get('/students/{id}', [StudentController::class,'edit'])->name('students.edit');
Route::get('/students', [StudentController::class,'index'])->name('students.index');
Route::get('/students3', [StudentController::class,'destroy'])->name('students.destroy');