<!DOCTYPE html>
<html>
  <head>
    <title></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
  margin: 0;
  padding: 0;
  background: #f2f2f2;
}

.forgot-password {
  width: 400px;
  margin: 0 auto;
  background: #fff;
  padding: 20px;
  border-radius: 5px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
}

.forgot-password h1 {
  text-align: center;
  font-size: 36px;
  margin-bottom: 30px;
}

.forgot-password form {
  display: flex;
  flex-direction: column;
}

.forgot-password label {
  font-size: 18px;
  margin-bottom: 10px;
}

.forgot-password input[type="email"] {
  padding: 10px;
  margin-bottom: 20px;
  border: none;
  border-radius: 5px;
  box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
}

.forgot-password button[type="submit"] {
  padding: 10px;
  background: #007bff;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background 0.3s ease;
}

.forgot-password button[type="submit"]:hover {
  background: #0069d9;
}

    </style>
  </head>
  <body>
    <div class="forgot-password">
      <h1>Mot de passe oublié</h1>
      <form method="post" action="reset-password.php">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" placeholder="Enter your email" required>

        <button type="submit" ><a href='/'>Restaurer mot de passe</a></button>
      </form>
    </div>
  </body>
</html>