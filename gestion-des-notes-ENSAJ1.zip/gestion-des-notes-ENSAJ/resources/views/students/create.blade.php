<!-- resources/views/students/create.blade.php -->
<!DOCTYPE html>
<html>
    <head>
        <title>Ajouter un compte</title>
        <style>
            body {
            margin: 0;
            padding: 0;
            background: #f2f2f2;
            }
            .login {
            width: 500px;
            margin: 0 auto;
            background: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            }
            .login h1 {
            text-align: center;
            font-size: 36px;
            margin-bottom: 30px;
            }
            .login form {
            display: flex;
            flex-direction: column;
            }
            .login label {
            font-size: 18px;
            margin-bottom: 10px;
            }
            .login input[type="text"],
            .login input[type="email"],
            
            .login input[type="password"] {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
            }
            .login button[type="submit"] {
            padding: 10px;
            background: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease;
            }
            .login button[type="submit"]:hover {
            background: #0069d9;
            }
            </style>
    </head>
    <body>
        <h1>Ajouter un compte</h1>
        <div class="login">
<form method="POST" action="{{ route('students.store') }}">
    @csrf
    
    <div>
        <label for="first_name">Prénom :</label>
        <input type="text" name="first_name" id="first_name" value="{{ old('first_name') }}" required>
    </div>
    <div>
        <label for="last_name">Nom de famille :</label>
        <input type="text" name="last_name" id="last_name" value="{{ old('last_name') }}" required>
    </div>
    <div>
        <label for="password">Mot de passe :</label>
        <input type="password" name="password" id="password" required>
    </div>
    <div>
        <label for="email">Adresse e-mail :</label>
        <input type="email" name="email" id="email" value="{{ old('email') }}" required>
    </div>
    <div>
        <label for="CNE">Code-Nationale-d'étudiant:</label>
        <input type="text" name="CNE" id="CNE" value="{{ old('CNE') }}" required>
    </div>  
   
    
    <button type="submit">Créer</button>
</form>
        </div>
    </body></html>