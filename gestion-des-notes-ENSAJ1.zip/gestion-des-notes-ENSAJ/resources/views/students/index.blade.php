<!DOCTYPE html>
<html>
<head>
    <title>Liste des étudiants</title>
</head>
<body>
    <h1>Liste des étudiants</h1>

    <ul>
        @foreach ($students as $student)
            <li><a href="{{ route('students.edit', $student->id) }}">{{ $student->first_name }} {{ $student->last_name }}</a></li>
        @endforeach
    </ul>
</body>
</html>
