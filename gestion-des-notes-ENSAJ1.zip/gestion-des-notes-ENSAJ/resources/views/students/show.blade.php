@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Détails de l'étudiant</h1>
                <p><strong>Nom d'utilisateur :</strong> {{ $student->username }}</p>
                <p><strong>Email :</strong> {{ $student->email }}</p>
                <p><strong>Prénom :</strong> {{ $student->first_name }}</p>
                <p><strong>Nom :</strong> {{ $student->last_name }}</p>
                <p><strong>Numéro de téléphone :</strong> {{ $student->phone_number }}</p>
                <p><strong>Adresse :</strong> {{ $student->address }}</p>
                <p><strong>Rôle :</strong> {{ $student->role }}</p>
            </div>
        </div>
    </div>
@endsection
